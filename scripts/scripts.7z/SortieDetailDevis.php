<?php

session_start();
include('../modeles/enteteAdmin.php');

?>
<div class="row">
    <div class="col-xs-3">

        <?php

        include('../scripts/connexionDB.php');
        $retour = connexion();
//$c=$retour[0];
        $link = $retour[0];

        include('../modeles/bar_menu.php');
        bar_sortie(4);
        include('calcultxt.php');

        echo ' </div> 

    <div class="col-xs-9 well3 ">';
        $ID_DV = $_POST['ID_DV'];
        //selection ligne de devis
        $sqlquery2 = "SELECT  L.ID_DV, sum((L.QTE_DV*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_DV*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', format(sum(A.VOL*L.QTE_DV),3,'fr_FR') as 'VOLDV'
               from CONTENIR_DV L, ARTICLE A
               where L.ID_DV='$ID_DV' AND A.ID_A=L.ID_A  ";
        $result2 = mysqli_query($link, $sqlquery2);
        $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);


        //selection client
        $sqlquery1 = "SELECT * , DATE_FORMAT(D.DATE_DV, '%d/%m/%Y') AS date_fr
              FROM  DEVIS D, CLIENT C
              WHERE D.ID_DV='$ID_DV' AND C.ID_C=D.ID_C";

        $result1 = mysqli_query($link, $sqlquery1);
        $row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);

        //The original date format.
        $original = $row1['DATE_DV'];
        list($year, $month, $day) = explode("-", $original);

        //Explode the string into an array.
        $exploded = explode("-", $original);

        //Reverse the order.
        $exploded = array_reverse($exploded);

        //Convert it back into a string.
        $newFormat = implode("/", $exploded);
        panel_tab_defaut('panel-info', '<div class="row">')

        ?>
        <div class="col-xs-12"> <h2 class="text-center"><img src="../images/facture.gif" width="100px" heigth="100" class="img-circle">&nbsp;&nbsp;&nbsp;&nbsp;<strong>Liste du devis</strong></h2> </div>
    </div>
    <div class="row">
        <div class=" col-xs-4 ">Devis :  <em class="ligneCommande"><?php echo $row1['REF_DV'] . '/' . $year ?></em> </div>
        <div class=" col-xs-4 ">Date :  <em class="ligneCommande"><?= $newFormat ?></em> </div>
        <div class="col-xs-4">Client :  <em class="ligneCommande"><?= $row1['RAISSO_C'] ?></em> </div>

    </div>
    <?php

    $req = "select *  FROM UNITE ";
    $res = mysqli_query($link, $req) or exit(mysql_error());
    $rows = array();
    while ($row = mysqli_fetch_array($res)) {
        $rows[] = $row;
    }
    //selection lignes devis pour chaque unité
    foreach ($rows as $row) {
        $unite = $row['UNITE'];

        $sqlquery = "SELECT A.ID_A, A.DESIGNATION, A.FAMILLE, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR,A.DIAMETRE, A.PV_HT, A.UNITE, A.VOL, A.QTE, L.QTE_DV, L.ID_A, L.ID_DV, (L.QTE_DV * A.QTE)*A.PV_HT as 'MONTANT',format(A.QTE*L.QTE_DV,3,'fr_FR') as VOLUME_U
        FROM  ARTICLE A, CONTENIR_DV L
        WHERE L.ID_DV='$ID_DV'  AND A.ID_A=L.ID_A AND A.UNITE='$unite'
        ORDER BY A.DESIGNATION ASC";

        $result = mysqli_query($link, $sqlquery);
        $nombre = mysqli_num_rows($result);
        ///s1 y a des lignes pour lunite
        if ($nombre != 0) {
            if ($unite == "M3") {
                //si type egal Lamelle colle
                $type = 6;
                //type different de LC
                $reqNLC = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_TYPE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_DV, C.ID_DV_LIGNE, C.QTE_DV, (C.QTE_DV*A.QTE)*A.PV_HT as 'MONTANT'
              FROM  ARTICLE A, CONTENIR_DV C
              WHERE  C.ID_DV='$ID_DV' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE!='$type' order by DESIGNATION ASC";

                $resNLC = mysqli_query($link, $reqNLC);
                $nombre1 = mysqli_num_rows($resNLC);
                if ($nombre1 > 0) {

                    ?>          
                    <table class="info" border="1">
                        <thead>  
                            <tr class="info">
                                <th width="200px"><strong>Désignation</strong></th>
                                <th width="60px"><strong>Quantité</strong></th>
                                <th width="55px"><strong>Long</strong></th>
                                <th width="55px"><strong>Larg</strong></th>
                                <th width="55px"><strong>Ep</strong></th>
                                <th width="50px"><strong></strong></th>
                                <th width="50px"><strong>M3</strong></th>
                                <th width="100px"><strong>Prix_Vente</strong></th>
                                <th width="100px"><strong>Montant</strong></th>


                            </tr>
                        </thead>
                        <?php

                        $MONTANT = 0;
                        $VOLUME = 0;
                        while ($rowNLC = mysqli_fetch_array($resNLC, MYSQLI_ASSOC)) {

                            ?>
                            <tr>
                                <td><?= $rowNLC['DESIGNATION'] ?></td>
                                <td><?php echo $rowNLC['QTE_DV'] ?></td>
                                <td><?php echo $rowNLC['LONGUEUR'] ?></td>
                                <td><?php echo $rowNLC['LARGEUR'] ?></td>
                                <td><?php echo $rowNLC['EPAISSEUR'] ?></td>
                                <td></td>
                                <td style="text-align:right"> <?php echo number_format($rowNLC['QTE'] * $rowNLC['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowNLC['PV_HT'], 0, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowNLC['MONTANT'], 0, ',', ' ') ?></td>
                            </tr>
                            <?php

                            $VOLUME = $VOLUME + $rowNLC['QTE'] * $rowNLC['QTE_DV'];
                        }
                        $sqlquery3 = "SELECT  A.UNITE, sum((L.QTE_DV*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_DV*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_DV) as 'VOLDV'
               from CONTENIR_DV L, ARTICLE A
               where L.ID_DV='$ID_DV' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE!='$type'";
                        if ($result3 = mysqli_query($link, $sqlquery3)) {
                            $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);
                        }

                        ?>
                        <td colspan="6" class="success"><strong>Total</strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong></td>
                        <td></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($row3['THT'], 0, ',', ' ') ?></strong></td>
                        </tr>
                    </table>
                    <hr> 
                    <?php

                }
                //fin NLC debut LC
                $reqLC = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_TYPE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_DV, C.ID_DV_LIGNE, C.QTE_DV, (C.QTE_DV*A.QTE)*A.PV_HT as 'MONTANT'
      FROM  ARTICLE A, CONTENIR_DV C
      WHERE  C.ID_DV='$ID_DV' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$type' order by DESIGNATION ASC";

                $resLC = mysqli_query($link, $reqLC);
                $nombre2 = mysqli_num_rows($resLC);

                if ($nombre2 > 0) {

                    ?>          
                    <table class="info" border="1">
                        <thead>  
                            <tr class="info">
                                <th width="200px"><strong>Désignation</strong></th>
                                <th width="60px"><strong>Quantité</strong></th>
                                <th width="55px"><strong>Long</strong></th>
                                <th width="55px"><strong>Larg</strong></th>
                                <th width="55px"><strong>Ep</strong></th>
                                <th width="50px"><strong></strong></th>
                                <th width="50px"><strong>M3</strong></th>
                                <th width="100px"><strong>Prix_Vente</strong></th>
                                <th width="100px"><strong>Montant</strong></th>


                            </tr>
                        </thead>
                        <?php

                        $MONTANT = 0;
                        $VOLUME = 0;
                        while ($rowLC = mysqli_fetch_array($resLC, MYSQLI_ASSOC)) {

                            ?>
                            <tr>
                                <td><?= $rowLC['DESIGNATION'] ?></td>
                                <td><?php echo $rowLC['QTE_DV'] ?></td>
                                <td><?php echo $rowLC['LONGUEUR'] ?></td>
                                <td><?php echo $rowLC['LARGEUR'] ?></td>
                                <td><?php echo $rowLC['EPAISSEUR'] ?></td>
                                <td></td>
                                <td style="text-align:right"> <?php echo number_format($rowLC['QTE'] * $rowLC['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowLC['PV_HT'], 0, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowLC['MONTANT'], 0, ',', ' ') ?></td>
                            </tr>
                            <?php

                            $VOLUME = $VOLUME + $rowLC['QTE'] * $rowLC['QTE_DV'];
                        }
                        $sqlquery3 = "SELECT  A.UNITE, sum((L.QTE_DV*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_DV*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_DV) as 'VOLDV'
               from DVNTENIR_DV L, ARTICLE A
               where L.ID_DV='$ID_DV' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$type'";
                        if ($result3 = mysqli_query($link, $sqlquery3)) {
                            $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);
                        }

                        ?>
                        <td colspan="6" class="success"><strong>Total</strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong></td>
                        <td></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($row3['THT'], 0, ',', ' ') ?></strong></td>
                        </tr>
                    </table>
                    <hr>
                    <?php

                }
            }
            //Fin LC debut M2
            elseif ($unite == "M2") {

                //si type egal a peindre
                $typeAP = 9;

                $reqAP = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_TYPE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_DV, C.ID_DV_LIGNE, C.QTE_DV, (C.QTE_DV*A.QTE)*A.PV_HT as 'MONTANT'
      FROM  ARTICLE A, CONTENIR_DV C
      WHERE  C.ID_DV='$ID_DV' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$typeAP' order by DESIGNATION ASC";

                $resAP = mysqli_query($link, $reqAP);
                $nombre2 = mysqli_num_rows($resAP);

                if ($nombre2 > 0) {

                    ?>          
                    <table class="info" border="1">
                        <thead>  
                            <tr class="info">
                                <th width="200px"><strong>Désignation</strong></th>
                                <th width="60px"><strong>Quantité</strong></th>
                                <th width="55px"><strong>Long</strong></th>
                                <th width="55px"><strong>Larg</strong></th>
                                <th width="55px"><strong>Ep</strong></th>
                                <th width="50px"><strong></strong></th>
                                <th width="50px"><strong>M3</strong></th>
                                <th width="100px"><strong>Prix_Vente</strong></th>
                                <th width="100px"><strong>Montant</strong></th>


                            </tr>
                        </thead>
                        <?php

                        $MONTANT = 0;
                        $VOLUME = 0;
                        while ($rowAP = mysqli_fetch_array($resAP, MYSQLI_ASSOC)) {

                            ?>
                            <tr>
                                <td><?= $rowAP['DESIGNATION'] ?></td>
                                <td><?php echo $rowAP['QTE_DV'] ?></td>
                                <td><?php echo $rowAP['LONGUEUR'] ?></td>
                                <td><?php echo $rowAP['LARGEUR'] ?></td>
                                <td><?php echo $rowAP['EPAISSEUR'] ?></td>
                                <td></td>
                                <td style="text-align:right"> <?php echo number_format($rowAP['QTE'] * $rowAP['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowAP['PV_HT'], 0, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowAP['MONTANT'], 0, ',', ' ') ?></td>
                            </tr>
                            <?php

                            $VOLUME = $VOLUME + $rowAP['QTE'] * $rowAP['QTE_DV'];
                        }
                        $sqlqueryAP3 = "SELECT  A.UNITE, sum((L.QTE_DV*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_DV*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_DV) as 'VOLDV'
               from CONTENIR_DV L, ARTICLE A
               where L.ID_DV='$ID_DV' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$typeAP'";
                        if ($resultAP3 = mysqli_query($link, $sqlqueryAP3)) {
                            $rowAP3 = mysqli_fetch_array($resultAP3, MYSQLI_ASSOC);
                        }

                        ?>
                        <td colspan="6" class="success"><strong>Total</strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong></td>
                        <td></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($rowAP3['THT'], 0, ',', ' ') ?></strong></td>
                        </tr>
                    </table>
                    <hr>
                    <?php

                }

                //type a vernir
                $typeAV = 3;

                $reqAV = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_TYPE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_DV, C.ID_DV_LIGNE, C.QTE_DV, (C.QTE_DV*A.QTE)*A.PV_HT as 'MONTANT'
      FROM  ARTICLE A, CONTENIR_DV C
      WHERE  C.ID_DV='$ID_DV' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$typeAV' order by DESIGNATION ASC";

                $resAV = mysqli_query($link, $reqAV);
                $nombreAV = mysqli_num_rows($resAV);

                if ($nombreAV > 0) {

                    ?>          
                    <table class="info" border="1">
                        <thead>  
                            <tr class="info">
                                <th width="200px"><strong>Désignation</strong></th>
                                <th width="60px"><strong>Quantité</strong></th>
                                <th width="55px"><strong>Long</strong></th>
                                <th width="55px"><strong>Larg</strong></th>
                                <th width="55px"><strong>Ep</strong></th>
                                <th width="50px"><strong></strong></th>
                                <th width="50px"><strong>M3</strong></th>
                                <th width="100px"><strong>Prix_Vente</strong></th>
                                <th width="100px"><strong>Montant</strong></th>


                            </tr>
                        </thead>
                        <?php

                        $MONTANT = 0;
                        $VOLUME = 0;
                        while ($rowAV = mysqli_fetch_array($resAV, MYSQLI_ASSOC)) {

                            ?>
                            <tr>
                                <td><?= $rowAV['DESIGNATION'] ?></td>
                                <td><?php echo $rowAV['QTE_DV'] ?></td>
                                <td><?php echo $rowAV['LONGUEUR'] ?></td>
                                <td><?php echo $rowAV['LARGEUR'] ?></td>
                                <td><?php echo $rowAV['EPAISSEUR'] ?></td>
                                <td></td>
                                <td style="text-align:right"> <?php echo number_format($rowAV['QTE'] * $rowAV['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowAV['PV_HT'], 0, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowAV['MONTANT'], 0, ',', ' ') ?></td>
                            </tr>
                            <?php

                            $VOLUME = $VOLUME + $rowAV['QTE'] * $rowAV['QTE_DV'];
                        }
                        $sqlqueryAV3 = "SELECT  A.UNITE, sum((L.QTE_DV*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_DV*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_DV) as 'VOLDV'
               from CONTENIR_DV L, ARTICLE A
               where L.ID_DV='$ID_DV' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$typeAV'";
                        $resultAV3 = mysqli_query($link, $sqlqueryAV3);
                        $rowAV3 = mysqli_fetch_array($resultAV3, MYSQLI_ASSOC);

                        ?>
                        <td colspan="6" class="success"><strong>Total</strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong></td>
                        <td></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($rowAV3['THT'], 0, ',', ' ') ?></strong></td>
                        </tr>
                    </table>
                    <hr>
                    <?php

                }
            } elseif ($unite == "ML") {
                //type egal Bois rond
                $type = 7;
                //chercher les Non bois rond
                $reqNBR = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_FAMILLE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_DV, C.ID_DV_LIGNE, C.QTE_DV, (C.QTE_DV*A.LONGUEUR)*A.PV_HT as 'MONTANT'
              FROM  ARTICLE A, CONTENIR_DV C
              WHERE  C.ID_DV='$ID_DV' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE!='$type' order by DESIGNATION ASC";

                $resNBR = mysqli_query($link, $reqNBR);
                $nombre3 = mysqli_num_rows($resNBR);
                if ($nombre3 > 0) {

                    ?>          
                    <table class="info saut" border="1">
                        <thead>  
                            <tr class="info">
                                <th width="30%"><strong>Produit</strong></th>
                                <th width="6%"><strong>Qté</strong></th>
                                <th width="7%"><strong>Long</strong></th>
                                <th width="7%"><strong>Larg</strong></th>
                                <th width="7%"><strong>Ep</strong></th>
                                <th width="7%"><strong>ML</strong></th>
                                <th width="7%"><strong>M3</strong></th>
                                <th width="15%"><strong>Prix unitaire</strong></th>
                                <th width="15%"><strong>Montant</strong></th>


                            </tr>
                        </thead>
                        <?php

                        $MONTANTNBR = 0;
                        $VOLUMENBR = 0;
                        $LONGUEURNBR = 0;
                        while ($rowNBR = mysqli_fetch_array($resNBR, MYSQLI_ASSOC)) {

                            ?>
                            <tr>
                                <td><?= $rowNBR['FAMILLE'] ?></td>
                                <td><?php echo $rowNBR['QTE_DV'] ?></td>
                                <td><?php echo $rowNBR['LONGUEUR'] ?></td>
                                <td><?php echo $rowNBR['LARGEUR'] ?></td>
                                <td><?php echo $rowNBR['EPAISSEUR'] ?></td>
                                <td style="text-align:right"> <?php echo number_format($rowNBR['LONGUEUR'] * $rowNBR['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"> <?php echo number_format($rowNBR['VOL'] * $rowNBR['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowNBR['PV_HT'], 0, ',', ' ') . " Ar" ?></td>
                                <td style="text-align:right"><?php echo number_format($rowNBR['MONTANT'], 0, ',', ' ') . " Ar" ?></td>
                            </tr>
                            <?php

                            $VOLUMENBR = $VOLUMENBR + $rowNBR['VOL'] * $rowNBR['QTE_DV'];

                            $LONGUEURNBR = $LONGUEURNBR + $rowNBR['LONGUEUR'] * $rowNBR['QTE_DV'];
                        }
                        $sqlquery3NBR = "SELECT  sum((L.QTE_DV*A.LONGUEUR)*A.PV_HT) as 'THT', sum((L.QTE_DV*A.LONGUEUR)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_DV) as 'VOLDV', sum(A.QTE*L.QTE_DV) as 'QTEDV'
               from CONTENIR_DV L, ARTICLE A
               where L.ID_DV='$ID_DV' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE!='$type'";
                        if ($result3NBR = mysqli_query($link, $sqlquery3NBR)) {
                            $row3NBR = mysqli_fetch_array($result3NBR, MYSQLI_ASSOC);
                        }

                        ?>
                        <td colspan="5" class="success"><strong>Total</strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($LONGUEURNBR, 3, ',', ' ') ?></strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUMENBR, 3, ',', ' ') ?></strong></td>
                        <td></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($row3NBR['THT'], 0, ',', ' ') . " Ar" ?></strong></td>
                        </tr>
                    </table>
                    <hr> 
                    <?php

                }
                $reqBR = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_FAMILLE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_DV, C.ID_DV_LIGNE, C.QTE_DV, (C.QTE_DV*A.QTE)*A.PV_HT as 'MONTANT'
      FROM  ARTICLE A, CONTENIR_DV C
      WHERE  C.ID_DV='$ID_DV' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$type' order by DESIGNATION ASC";

                $resBR = mysqli_query($link, $reqBR);
                $nombre4 = mysqli_num_rows($resBR);
                if ($nombre4 > 0) {

                    ?>          
                    <table class="info saut" border="1">
                        <thead>  
                            <tr class="info">
                                <th width="30%"><strong>Produit</strong></th>
                                <th width="6%"><strong>Qté</strong></th>
                                <th width="7%"><strong>Long</strong></th>
                                <th width="7%"><strong>Diam</strong></th>
                                <th width="7%"><strong></strong></th>
                                <th width="7%"><strong>ML</strong></th>
                                <th width="7%"><strong>M3</strong></th>
                                <th width="15%"><strong>Prix unitaire</strong></th>
                                <th width="15%"><strong>Montant</strong></th>
                            </tr>
                        </thead>
                        <?php

                        $MONTANT = 0;
                        $MONTANTBR = 0;
                        $VOLUMEBR = 0;
                        $LONGUEURBR = 0;
                        while ($rowBR = mysqli_fetch_array($resBR, MYSQLI_ASSOC)) {
                            /* if($rowBR['TEMP']!=0){
                              $LONG=$rowBR['TEMP'];
                              $RAY=$rowBR['DIAMETRE']/2000;
                              $VOL=$LONG*(($RAY*$RAY)*3.14);
                              $MONTANTBR=$rowBR['PV_HT']*$LONG*$rowBR['QTE_DV'];
                              }
                              else
                              { */
                            $LONG = $rowBR['LONGUEUR'];
                            $VOL = $rowBR['VOL'];
                            $MONTANTBR = $rowBR['MONTANT'];

                            ?>
                            <tr>
                                <td><?= $rowBR['FAMILLE'] ?></td>
                                <td><?php echo $rowBR['QTE_DV'] ?></td>
                                <td><?php echo $LONG ?></td>
                                <td><?php echo $rowBR['DIAMETRE'] ?></td>
                                <td></td>
                                <td style="text-align:right"> <?php echo number_format($LONG * $rowBR['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"> <?php echo number_format($VOL * $rowBR['QTE_DV'], 3, ',', ' ') ?></td>
                                <td style="text-align:right"><?php echo number_format($rowBR['PV_HT'], 0, ',', ' ') . " Ar" ?></td>
                                <td style="text-align:right"><?php echo number_format($MONTANTBR, 0, ',', ' ') . " Ar" ?></td>
                            </tr>
                            <?php

                            $VOLUMEBR = $VOLUMEBR + $VOL * $rowBR['QTE_DV'];
                            $LONGUEURBR = $LONGUEURBR + $LONG * $rowBR['QTE_DV'];
                            $MONTANT = $MONTANT + $MONTANTBR;
                        }
                        $sqlquery3BR = "SELECT  A.UNITE, A.ID_FAMILLE ,  sum((L.QTE_DV*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_DV*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_DV) as 'VOLDV'
               from CONTENIR_DV L, ARTICLE A
               where L.ID_DV='$ID_DV' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$type'";
                        if ($result3BR = mysqli_query($link, $sqlquery3BR)) {
                            $row3BR = mysqli_fetch_array($result3BR, MYSQLI_ASSOC);
                        }

                        ?>
                        <td colspan="5" class="success"><strong>Total</strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($LONGUEURBR, 3, ',', ' ') ?></strong></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUMEBR, 3, ',', ' ') ?></strong></td>
                        <td></td>
                        <td class="" style="text-align:right"><strong><?php echo number_format($MONTANT, 0, ',', ' ') . " Ar" ?></strong></td>
                        </tr>
                    </table>
                    <hr>
                    <?php

                }
            }
        }
    }

    ?>
    <table class="info saut" border="1" style="width:100%">
   <!--  <tr><td colspan="9">&nbsp;</td></tr>-->
        <tr>
            <td style="width:64%" class="success"><strong>TOTAL</strong></td>
            <td style="text-align:right ;width:7%"><strong><?php echo $row2['VOLDV'] ?></strong></td>
            <td  style="width:15%"></td>
            <td  style="text-align:right; width:15%"><strong><?php echo number_format($row2['THT'], 0, ',', ' ') . " Ar" ?></strong></td>
        </tr>
        <tr>
            <td style="width:64%" class="success noborder" style="border-right: none;"><strong>TVA 20%</strong></td>
            <td  style="width:7%" class="noborder"></td>
            <td  style="width:15%" class="noborder"></td>
            <td style="width:15%; text-align:right"><strong><?php echo number_format($row2['TTC'] - $row2['THT'], 0, ',', ' ') . " Ar" ?></strong></td>
        </tr>
        <tr>
            <td style="width:64%" class="success noborder"><strong>TOTAL TTC</strong></td>
            <td  style="width:7%"  class="noborder"></td>
            <td  style="width:15%"  class="noborder"></td>
            <td style="width:15%; text-align:right"><strong><?php echo number_format($row2['TTC'], 0, ',', ' ') . " Ar" ?></strong></td>
        </tr>
        <tr>
            <td>
                <input id="t" type="text" value="<?php echo round($row2['TTC'], 0) ?>"/> 
            </td>
            <td colspan="7">
                <form name="lettrespdf" type="post" target="_blank" action="SortieDetailDevis2.php">     
                    <input id='lettres'  type="text" name="lettres" value="&nbsp;" style='font-family:verdana; font-size:11px;'>
                    </td>
                    </tr>
                    </table>
                    <div class="row">
                        <div class="col-xs-3">
                            <label for="text" >Délai</label>
                        </div>
                        <div class="col-xs-9">
                            <input type="text" style="width: 450px;" max-lenght="400" name="comment1" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-3">
                            <label for="text" >Validité</label>
                        </div>
                        <div class="col-xs-9">
                            <input type="text" style="width: 450px;" max-lenght="400" name="comment2" >
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-4">
                            <label for="text" >Conditions de paiement</label>
                        </div>
                        <div class="col-xs-8">
                            <input type="text" style="width: 450px;" max-lenght="400" name="comment3">
                        </div>
                    </div>
                    <!--Div de la fonction panel_tab-->
                    </div>
                    <a href="../scripts/SortieDevis.php"><input type="image" src="../images/retour2.PNG" width="70" heigth="70" title="Retour aux Devis"></a>
                    <Button type="submit" name="ID_DV"  class="pull-right"  value="<?= $row1['ID_DV'] ?>"><img src="../images/avant.PNG" width="70" heigth="70" style="background-image:transparent ;" /></Button></form>
                </div>
                </div>



                <script type="text/javascript">

                    var res, plus, diz, s, un, mil, mil2, ent, deci, centi, pl, pl2, conj;

                    var t = ["", "Un", "Deux", "Trois", "Quatre", "Cinq", "Six", "Sept", "Huit", "Neuf"];
                    var t2 = ["Dix", "Onze", "Douze", "Treize", "Quatorze", "Quinze", "Seize", "Dix-sept", "Dix-huit", "Dix-neuf"];
                    var t3 = ["", "", "Vingt", "Trente", "Quarante", "Cinquante", "Soixante", "Soixante", "Quatre-vingt", "Quatre-vingt"];



                    window.onload = calcule

                    function calcule() {
                        document.getElementById("t").onfocus = function () {
                            document.getElementById("lettres").value = trans(this.value)
                        }
                    }

                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // traitement des deux parties du nombre;
                    function decint(n) {

                        switch (n.length) {
                            case 1 :
                                return dix(n);
                            case 2 :
                                return dix(n);
                            case 3 :
                                return cent(n.charAt(0)) + " " + decint(n.substring(1));
                            default:
                                mil = n.substring(0, n.length - 3);
                                if (mil.length < 4) {
                                    un = (mil == 1) ? "" : decint(mil);
                                    return un + mille(mil) + " " + decint(n.substring(mil.length));
                                } else {
                                    mil2 = mil.substring(0, mil.length - 3);
                                    return decint(mil2) + million(mil2) + " " + decint(n.substring(mil2.length));
                                }
                        }
                    }



                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // traitement des nombres entre 0 et 99, pour chaque tranche de 3 chiffres;
                    function dix(n) {
                        if (n < 10) {
                            return t[parseInt(n)]
                        } else if (n > 9 && n < 20) {
                            return t2[n.charAt(1)]
                        } else {
                            plus = n.charAt(1) == 0 && n.charAt(0) != 7 && n.charAt(0) != 9 ? "" : (n.charAt(1) == 1 && n.charAt(0) < 8) ? " et " : "-";
                            diz = n.charAt(0) == 7 || n.charAt(0) == 9 ? t2[n.charAt(1)] : t[n.charAt(1)];
                            s = n == 80 ? "s" : "";

                            return t3[n.charAt(0)] + s + plus + diz;
                        }
                    }


                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // traitement des mots "cent", "mille" et "million"
                    function cent(n) {
                        return n > 1 ? t[n] + " Cent" : (n == 1) ? " Cent" : "";
                    }

                    function mille(n) {
                        return n >= 1 ? " Mille" : "";
                    }

                    function million(n) {
                        return n >= 1 ? " Millions" : " Million";
                    }


                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                // conversion du nombre
                    function trans(n) {

                        // vérification de la valeur saisie
                        if (!/^\d+[.,]?\d*$/.test(n)) {
                            return "L'expression entrée n'est pas un nombre."
                        }

                        // séparation entier + décimales
                        n = n.replace(/(^0+)|(\.0+$)/g, "");
                        n = n.replace(/([.,]\d{2})\d+/, "$1");
                        n1 = n.replace(/[,.]\d*/, "");
                        n2 = n1 != n ? n.replace(/\d*[,.]/, "") : false;

                        // variables de mise en forme
                        ent = !n1 ? "" : decint(n1);
                        deci = !n2 ? "" : decint(n2);
                        if (!n1 && !n2) {
                            return  "Entrez une valeur non nulle!"
                        }
                        conj = !n2 || !n1 ? "" : "  et ";
                        euro = !n1 ? "" : !/[23456789]00$/.test(n1) ? " Ariary" : " ";
                        centi = !n2 ? "" : " centime";
                        pl = n1 > 1 ? "" : "";
                        pl2 = n2 > 1 ? "s" : "";

                        // expression complète en toutes lettres
                        return (" " + ent + euro + pl + conj + deci + centi + pl2).replace(/\s+/g, " ").replace("cent s E", "cents E");

                    }

                </script>
                <?php include('../modeles/pied.php'); ?>