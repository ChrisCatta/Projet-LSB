<!DOCTYPE html>
<html lang="fr">
    <html>
        <head>
            <meta charset="utf-8" />
            <title>Devis</title>
            <link rel="stylesheet" type="text/css" href="../bootstrap/dist/css/bootstrap.min.css">
            <link rel="stylesheet" type="text/css" href="../jquery/css/jquery-ui.css">
            <link rel="stylesheet" type="text/css" href="../DataTables/jquery.dataTables.min.css">
            <link rel="stylesheet" type="text/css" href="../bootstrap/dist/css/bootstrap-select.min.css">
            <link rel="stylesheet" type="text/css" href="../LSB.css">
            <!--////////////////////-->
            <style>
                .facture{
                    border: 1px solid #3a3a3a;
                    margin-bottom: 20px;
                    margin-top: 20px;
                }
                table{
                    margin-bottom: 20px;
                    border-collapse: collapse;
                }
                .adresse{
                    border:1px solid black;
                    border-radius:10px;
                }
                input {
                    display: inline;
                    white-space: nowrap;
                    border: 1px solid #999;
                }
                input:before {
                    content: attr(value);
                }
                .pied{
                    font-size: 10px;
                    color:black;
                }
                .pagenum:before {
                    content: counter(page);
                }
            </style>
        </head>
        <body class="imp">
            <?php

            include('../scripts/conn.php');
            $retour = connexion();
//$c=$retour[0];
            $link = $retour[0];

            ?>
            <div class="container">
                <div class="col-xs-12 ">
                    <?php

                    if (isset($_POST['ID_CO'])) {
                        $ID_CO = $_POST['ID_CO'];
                        $comment1 = $_POST['comment1'];
                        $comment2 = $_POST['comment2'];
                        $comment3 = $_POST['comment3'];
                        echo $_POST['ID_CO'];
                    }
                    if (isset($_GET['ID_CO'])) {
                        $ID_CO = $_GET['ID_CO'];
                        $comment1 = $_GET['comment1'];
                        $comment2 = $_GET['comment2'];
                        $comment3 = $_GET['comment3'];
                    }
                    $lettres = $_GET['lettres'];

                    $sqlquery2 = "SELECT  L.ID_CO, sum((L.QTE_CO*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_CO*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', format(sum(A.VOL*L.QTE_CO),3,'fr_FR') as 'VOLCO'
               from CONTENIR_CO L, ARTICLE A
               where L.ID_CO='$ID_CO' AND A.ID_A=L.ID_A  ";
                    $result2 = mysqli_query($link, $sqlquery2);
                    $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);

                    $sqlquery1 = "SELECT D.ID_CO, D.REF_CO,  D.ID_C, D.DATE_CO, YEAR(D.DATE_CO) AS annee, CL.ID_C, CL.RAISSO_C, CL.ADRESSE_C, CL.TEL_C, CL.EMAIL, CL.NIF, CL.STAT, DATE_FORMAT(D.DATE_CO, '%d/%m/%Y') AS date_fr
              FROM COMMANDE D, CLIENT CL
              WHERE D.ID_CO='$ID_CO'  AND  CL.ID_C=D.ID_C";
                    $result1 = mysqli_query($link, $sqlquery1);
                    $row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);

                    //The original date format.
                    $original = $row1['DATE_CO'];
                    list($year, $month, $day) = explode("-", $original);

                    //Explode the string into an array.
                    $exploded = explode("-", $original);

                    //Reverse the order.
                    $exploded = array_reverse($exploded);

                    //Convert it back into a string.
                    $newFormat = implode("/", $exploded);

                    ?>

                    <div class="row">
                        <div class="col-xs-4 ">
                            <div class="adresse">
                                <p><img src="../images/logo-lsb.png"  width="200px"/></p>
                                <div class="pied"> 
                                    B.P. 1140 - 301-Fianarantsoa <br>Madagascar<br>  
                                    +261 20 75 522 44 / 032 03 421 03<br>lsb@moov.mg </div>
                            </div>
                        </div>
                        <div class="col-xs-4">     
                            <h2 style="text-align: center;"><strong>Facture</strong></h2>
                        </div>
                        <div class="col-xs-4 ">
                            <p style="text-align: right; top:0px;">Fianarantsoa le : <em class="ligneCommande"><?php echo $newFormat; ?></em></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-3 ">
                            N°:  <em class="ligneCommande"><?php echo $row1['REF_CO'] . '/' . $year ?></em>
                        </div> 
                        <div class="col-xs-offset-4 col-xs-5">
                            <em class="ligneCommande"><?= $row1['RAISSO_C'] ?></em>
                            <br>
                            <em class="ligneCommande"><?= $row1['ADRESSE_C'] ?></em>
                            <br>
                            <em class="ligneCommande"><?= $row1['TEL_C'] ?></em>
                            <br>
                            <em class="ligneCommande"><?= $row1['EMAIL'] ?></em>
                            <br>
                            NIF :<em class="ligneCommande"><?= $row1['NIF'] ?></em>
                            <br>
                            STAT :<em class="ligneCommande"><?= $row1['STAT'] ?></em>
                            <br>
                            RC :<em class="ligneCommande"><?= $row1['NIF'] ?></em>
                            <br>
                            CIF :<em class="ligneCommande"><?= $row1['STAT'] ?></em>
                        </div>
                    </div>
                    <?php

                    $req = "select *  FROM UNITE ";
                    $res = mysqli_query($link, $req) or exit(mysql_error());
                    $rows = array();
                    while ($ligne = mysqli_fetch_array($res)) {
                        $rows[] = $ligne;
                    }
                    foreach ($rows as $ligne) {
                        $unite = $ligne['UNITE'];

                        $sqlquery = "SELECT  A.UNITE, A.QTE, A.VOL, A.ID_A, A.DESIGNATION,A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE,  L.ID_CO, L.ID_A, L.ID_CO_LIGNE, L.QTE_CO, (L.QTE_CO*A.QTE)*A.PV_HT as 'MONTANT'
              FROM  ARTICLE A, CONTENIR_CO L
              WHERE  L.ID_CO='$ID_CO' AND A.ID_A=L.ID_A AND A.UNITE='$unite'
              ORDER BY A.DESIGNATION ASC";

                        $result = mysqli_query($link, $sqlquery);
                        $nombre = mysqli_num_rows($result);
                        if ($nombre != 0) {
                            if ($unite == "M3") {
                                $type = 6;
                                $reqNLC = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_TYPE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_CO, C.ID_CO_LIGNE, C.QTE_CO, (C.QTE_CO*A.QTE)*A.PV_HT as 'MONTANT'
              FROM  ARTICLE A, CONTENIR_CO C
              WHERE  C.ID_CO='$ID_CO' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE!='$type' order by DESIGNATION ASC";

                                if ($resNLC = mysqli_query($link, $reqNLC)) {
                                    $nombre1 = mysqli_num_rows($resNLC);

                                    ?>          
                                    <table class="info saut" border="1">
                                        <thead>  
                                            <tr class="info">
                                                <th width="30%"><strong>Désignation</strong></th>
                                                <th width="6%"><strong>Qté</strong></th>
                                                <th width="7%"><strong>Long</strong></th>
                                                <th width="7%"><strong>Larg</strong></th>
                                                <th width="7%"><strong>Ep</strong></th>
                                                <th width="7%"><strong></strong></th>
                                                <th width="7%"><strong>M3</strong></th>
                                                <th width="15%"><strong>Prix_Vente</strong></th>
                                                <th width="15%"><strong>Montant</strong></th>
                                            </tr>
                                        </thead>
                                        <?php

                                        $MONTANT = 0;
                                        $VOLUME = 0;
                                        while ($rowNLC = mysqli_fetch_array($resNLC, MYSQLI_ASSOC)) {

                                            ?>
                                            <tr>
                                                <td><?= $rowNLC['DESIGNATION'] ?></td>
                                                <td><?php echo $rowNLC['QTE_CO'] ?></td>
                                                <td><?php echo $rowNLC['LONGUEUR'] ?></td>
                                                <td><?php echo $rowNLC['LARGEUR'] ?></td>
                                                <td><?php echo $rowNLC['EPAISSEUR'] ?></td>
                                                <td></td>
                                                <td style="text-align:right"> <?php echo number_format($rowNLC['QTE'] * $rowNLC['QTE_CO'], 3, ',', ' ') ?></td>
                                                <td style="text-align:right"><?php echo number_format($rowNLC['PV_HT'], 0, ',', ' ') ?></td>
                                                <td style="text-align:right"><?php echo number_format($rowNLC['MONTANT'], 0, ',', ' ') ?></td>
                                            </tr>
                                            <?php

                                            $VOLUME = $VOLUME + $rowNLC['QTE'] * $rowNLC['QTE_CO'];
                                        }
                                        $sqlquery3 = "SELECT  A.UNITE, sum((L.QTE_CO*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_CO*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_CO) as 'VOLCO'
               from CONTENIR_CO L, ARTICLE A
               where L.ID_CO='$ID_CO' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE!='$type'";
                                        if ($result3 = mysqli_query($link, $sqlquery3)) {
                                            $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);
                                        }

                                        ?>
                                        <td colspan="5" class="success"><strong>Total</strong></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong></td>
                                        <td></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($row3['THT'], 0, ',', ' ') ?></strong></td>
                                        </tr>
                                    </table>
                                    <hr> 
                                    <?php

                                }
                                $reqLC = "SELECT A.UNITE, A.QTE, A.VOL, A.ID_A, A.ID_TYPE, A.DESIGNATION, A.LONGUEUR, A.LARGEUR, A.UNITE, A.EPAISSEUR, A.DIAMETRE, A.PV_HT, A.FAMILLE, A.TYPE, C.ID_CO, C.ID_CO_LIGNE, C.QTE_CO, (C.QTE_CO*A.QTE)*A.PV_HT as 'MONTANT'
      FROM  ARTICLE A, CONTENIR_CO C
      WHERE  C.ID_CO='$ID_CO' AND A.ID_A=C.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$type' order by DESIGNATION ASC";

                                if ($resLC = mysqli_query($link, $reqLC)) {

                                    ?>          
                                    <table class="info saut" border="1">
                                        <thead>  
                                            <tr class="info">
                                                <th width="30%"><strong>Désignation</strong></th>
                                                <th width="6%"><strong>Qté</strong></th>
                                                <th width="7%"><strong>Long</strong></th>
                                                <th width="7%"><strong>Larg</strong></th>
                                                <th width="7%"><strong>Ep</strong></th>
                                                <th width="7%"><strong></strong></th>
                                                <th width="7%"><strong>M3</strong></th>
                                                <th width="15%"><strong>Prix_Vente</strong></th>
                                                <th width="15%"><strong>Montant</strong></th>
                                            </tr>
                                        </thead>
                <?php

                $MONTANT = 0;
                $VOLUME = 0;
                while ($rowLC = mysqli_fetch_array($resLC, MYSQLI_ASSOC)) {

                    ?>
                                            <tr>
                                                <td><?= $rowLC['DESIGNATION'] ?></td>
                                                <td><?php echo $rowLC['QTE_CO'] ?></td>
                                                <td><?php echo $rowLC['LONGUEUR'] ?></td>
                                                <td><?php echo $rowLC['LARGEUR'] ?></td>
                                                <td><?php echo $rowLC['EPAISSEUR'] ?></td>
                                                <td></td>
                                                <td style="text-align:right"> <?php echo number_format($rowLC['QTE'] * $rowLC['QTE_CO'], 3, ',', ' ') ?></td>
                                                <td style="text-align:right"><?php echo number_format($rowLC['PV_HT'], 0, ',', ' ') ?></td>
                                                <td style="text-align:right"><?php echo number_format($rowLC['MONTANT'], 0, ',', ' ') ?></td>
                                            </tr>
                                            <?php

                                            $VOLUME = $VOLUME + $rowLC['QTE'] * $rowLC['QTE_CO'];
                                        }
                                        $sqlquery3 = "SELECT  A.UNITE, sum((L.QTE_CO*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_CO*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_CO) as 'VOLCO'
               from CONTENIR_CO L, ARTICLE A
               where L.ID_CO='$ID_CO' AND A.ID_A=L.ID_A AND A.UNITE='$unite' AND A.ID_TYPE='$type'";
                                        if ($result3 = mysqli_query($link, $sqlquery3)) {
                                            $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);
                                        }

                                        ?>
                                        <td colspan="5" class="success"><strong>Total</strong></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong></td>
                                        <td></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($row3['THT'], 0, ',', ' ') ?></strong></td>
                                        </tr>
                                    </table>
                                    <hr>
                <?php

            }
        } elseif ($unite == "M2") {

            ?>           <table class="info saut" border="1" >
                                    <!--<tr>
                                      <td width="20%"><strong><?= $row['UNITE'] ?></strong></td>
                                    </tr>-->
                                    <thead>  
                                        <tr class="success">
                                            <th width="30%"><strong>Désignation</strong></th>
                                            <th width="6%"><strong>Qté</strong></th>
                                            <th width="7%"><strong>Long</strong></th>
                                            <th width="7%"><strong>Larg</strong></th>
                                            <th width="7%"><strong>Ep</strong></th>
                                            <th width="7%"><strong>M2</strong></th>
                                            <th width="7%"><strong>M3</strong></th>
                                            <th width="15%"><strong>Prix_Vente</strong></th>
                                            <th width="15%"><strong>Montant</strong></th>
                                        </tr>
                                    </thead>
            <?php

            $VOLUME = 0;
            $SURFACE = 0;
            while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {

                ?>
                                        <tr>
                                            <td> <?php echo $row['DESIGNATION'] ?></td>
                                            <td><?php echo $row['QTE_CO'] ?></td>
                                            <td><?php echo $row['LONGUEUR'] ?></td>
                                            <td><?php echo $row['LARGEUR'] ?></td>
                                            <td><?php echo $row['EPAISSEUR'] ?></td>
                                            <td style="text-align:right"> <?php echo number_format($row['QTE'] * $row['QTE_CO'], 3, ',', ' ') ?></td>
                                            <td style="text-align:right"> <?php echo number_format($row['VOL'] * $row['QTE_CO'], 3, ',', ' ') ?></td>
                                            <td style="text-align:right"><?php echo number_format($row['PV_HT'], 0, ',', ' ') ?></td>
                                            <td style="text-align:right"><?php echo number_format($row['MONTANT'], 0, ',', ' ') ?></td>
                                        </tr>
                                        <tr>
                <?php

                $VOLUME = $VOLUME + $row['VOL'] * $row['QTE_CO'];
                $SURFACE = $SURFACE + $row['QTE'] * $row['QTE_CO'];
            }
            $sqlquery3 = "SELECT  A.UNITE, sum((L.QTE_CO*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_CO*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_CO) as 'VOLCO'
               from CONTENIR_CO L, ARTICLE A
               where L.ID_CO='$ID_CO' AND A.ID_A=L.ID_A AND A.UNITE='$unite'";
            if ($result3 = mysqli_query($link, $sqlquery3)) {
                $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);
            }

            ?>
                                        <td colspan="5" class="success"><strong>Total</strong></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($SURFACE, 3, ',', ' ') ?></strong></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong></td>
                                        <td></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($row3['THT'], 0, ',', ' ') ?></strong></td>
                                    </tr>
                                </table>
                                <hr>
            <?php

        } elseif ($unite == "ML") {

            ?>
                                <table class="info saut" border="1" width="100%" >
                                  <!--<tr>
                                    <td width="20%"><strong><?= $row['UNITE'] ?></strong></td>
                                  </tr>-->
                                    <thead>  
                                        <tr class="success">
                                            <th width="30%"><strong>Désignation</strong></th>
                                            <th width="6%"><strong>Qté</strong></th>
                                            <th width="7%"><strong>Long</strong></th>
                                            <th width="7%"><strong>Diam</strong></th>
                                            <th width="7%"><strong></strong></th>
                                            <th width="7%"><strong>ML</strong></th>
                                            <th width="7%"><strong>M3</strong></th>
                                            <th width="15%"><strong>Prix_Vente</strong></th>
                                            <th width="15%"><strong>Montant</strong></th>
                                        </tr>
                                    </thead>
            <?php

            $VOLUME = 0;
            $QUANTITE = 0;
            while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {

                ?>
                                        <tr>

                                            <td> <?php echo $row['DESIGNATION'] ?></td>
                                            <td><?php echo $row['QTE_CO'] ?></td>
                                            <td><?php echo number_format($row['LONGUEUR'], 3, ',', ' ') ?></td>
                                            <td><?php echo number_format(($row['DIAMETRE'] / 1000), 3, ',', ' ') ?></td>
                                            <td></td>
                                            <td style="text-align:right"> <?php echo number_format($row['QTE'] * $row['QTE_CO'], 0, ',', ' ') ?></td>
                                            <td style="text-align:right"> <?php echo number_format($row['VOL'] * $row['QTE_CO'], 3, ',', ' ') ?></td>
                                            <td style="text-align:right"><?php echo number_format($row['PV_HT'], 0, ',', ' ') . " Ar" ?></td>
                                            <td style="text-align:right"><?php echo number_format($row['MONTANT'], 0, ',', ' ') . " Ar" ?></td>
                                        </tr>
                                        <tr>
                <?php

                $VOLUME = $VOLUME + $row['VOL'] * $row['QTE_CO'];
                $QUANTITE = $QUANTITE + $row['QTE'] * $row['QTE_CO'];
            }

            $sqlquery3 = "SELECT  A.UNITE, sum((L.QTE_CO*A.QTE)*A.PV_HT) as 'THT', sum((L.QTE_CO*A.QTE)*A.PV_HT*(1+0.20)) as 'TTC', sum(A.VOL*L.QTE_CO) as 'VOLCO', sum(A.QTE*L.QTE_CO) as 'QTECO'
               from CONTENIR_CO L, ARTICLE A
               where L.ID_CO='$ID_CO' AND A.ID_A=L.ID_A AND A.UNITE='$unite'";
            if ($result3 = mysqli_query($link, $sqlquery3)) {
                $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);
            }

            ?>
                                        <td colspan="5" class="success"><strong>Total</strong></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($QUANTITE, 0, ',', ' ') ?></strong></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($VOLUME, 3, ',', ' ') ?></strong>
                                        <td></td>
                                        <td class="" style="text-align:right"><strong><?php echo number_format($row3['THT'], 0, ',', ' ') . " Ar" ?></strong></td>
                                    </tr>
                                </table>
            <?php

        }
    }
}

?>
                    <table class="info saut" border="1" width="100%">
                   <!--  <tr><td colspan="9">&nbsp;</td></tr>-->
                        <tr>
                            <td style="width:64%" class="success"><strong>Total</strong></td>
                            <td style="text-align:right ;width:7%"><strong><?php echo $row2['VOLCO'] ?></strong></td>
                            <td  style="width:15%"></td>
                            <td  style="text-align:right; width:15%"><strong><?php echo number_format($row2['THT'], 0, ',', ' ') . " Ar" ?></strong></td>
                        </tr>
                        <tr>
                            <td style="width:64%" class="success noborder" style="border-right: none;"><strong>TVA 20%</strong></td>
                            <td  style="width:7%" class="noborder"></td>
                            <td  style="width:15%" class="noborder"></td>
                            <td style="width:15%; text-align:right"><strong><?php echo number_format($row2['TTC'] - $row2['THT'], 0, ',', ' ') . " Ar" ?></strong></td>
                        </tr>
                        <tr>
                            <td style="width:64%" class="success noborder"><strong>Total TTC</strong></td>
                            <td  style="width:7%"  class="noborder"></td>
                            <td  style="width:15%"  class="noborder"></td>
                            <td style="width:15%; text-align:right"><strong><?php echo number_format($row2['TTC'], 0, ',', ' ') . " Ar" ?></strong></td>

                    </table>
                </div>
                <div >Le montant de la présente facture est arreté a la somme de : <h5><?= $lettres ?> (<?php echo number_format($row2['TTC'], 0, ',', ' ') . " Ar" ?>)</h5></div>
                <div> Délai : <?= $comment1 ?></div> 
                <div> Validité : <?= $comment2 ?></div> 
                <div> Conditions de paiement : <?= $comment3 ?></div> 
            </div>
        </div>
<?php include('../modeles/pied-imp.php'); ?> 
        <script> $(document).ready(function () {
                $('.selectpicker').selectpicker();
            });
        </script>
    </div>
</body>
</html>