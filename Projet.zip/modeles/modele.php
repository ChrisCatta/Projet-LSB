<?php include('../modeles/entete.php'); ?>
<table width="1350" border="0" cellpadding="100" cellspacing="10" height="440" valign="top" bgcolor="#ABAD68">
  <tr >
    <td >
      <!--h3>Système de gestion des stages</h3-->
      <p><em>Notre corps</em></p>
    </td>
    
  </tr>

  

</table>

<?php include('../modeles/pied.php'); ?>