    
<div class="row saut footer-imp">
        <h5 style="text-align: center">Les scieries du Betsileo SURL</h5>
        <p  class="pied" >Statistique : 16101 21 1998 0 00030 - 
            NIF : 2000024240 - 
            RC : 2012 B 00010 - 
            CIF : 0039668/DGI-F du 01/01/2018<br>
            Coordonnées bancaires :<br>
            Fianarantsoa BNI N° : 00005 00052 473 313 7 010 0 15 - 
            Antananarivo BNI N° : 00005 00001 473 313 7 010 0 04<br>
            <!--Skype : lesscieriesdubetsileo<br>-->
            <a  href="http://scieries-madagascar.com/">Site internet : http://scieries-madagascar.com/</a><br>https://www.facebook.com/scieries.madagascar/timeline</a>
        </p>
</div> 