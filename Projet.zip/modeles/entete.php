<!DOCTYPE html>
<html lang="fr">
      <head>
	       <meta charset="utf-8" />
           <link rel="shortcut icon" href="../bootsrap/docs/assets/ico/repro.PNG">
		   <title>Stock LSB </title>
       <link rel="stylesheet" href="../jquery/development-bundle/themes/base/jquery.ui.all.css">
       <link rel="stylesheet" href="../jquery/css/dark-hive/jquery-ui-1.10.4.custom.min.css">
           <link rel="stylesheet" type="text/css" href="../bootstrap/dist/css/bootstrap.min.css">
           <link rel="stylesheet" type="text/css" href="../cefis.css">
           <link href="../LSB.css" rel="stylesheet" type="text/css">

    <!--link rel="stylesheet" href="../jquery/development-bundle/demos/demos.css"-->
    <script src="../jquery/jquery-3.2.1.min.js"></script>
    <script src="../jquery/development-bundle/ui/jquery.ui.core.js"></script>
  <script src="../jquery/development-bundle/ui/jquery.ui.widget.js"></script>
  <script src="../jquery/development-bundle/ui/jquery.ui.accordion.js"></script>
  <script src="../jquery/development-bundle/ui/jquery.ui.datepicker.js"></script>
  <script src="../jquery/development-bundle/ui/jquery.ui.button.js"></script>
 <script>
  $(function() {
   $( "#accordion" ).accordion({
      heightStyle: "content"
    });
   $( "#accordion1" ).accordion({
      heightStyle: "content"
    });
  
     $( "#datepicker" ).datepicker();
     $( "input[type=submit], button" ).button();
  });

</script>
   </head>
<body >
	<div class="container">
          <div class="row entete">
              <img src="../images/logo-lsb.png" width="400" heigth="150" >
           </div>
          
			
			