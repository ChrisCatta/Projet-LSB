<table width="1350" border="0" cellpadding="2" cellspacing="5" >
  <tr>
  	<td>&nbsp;</td>
    <td><div align="right"><a href='menu.php?SID'>Retour au Menu</a></div>
    </td>
  </tr>
</table>