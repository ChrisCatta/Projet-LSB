    
<div class="row saut footer-imp">
        <h5 style="text-align: center">Les Scieries du Betsileo SURL</h5>
        <p  class="pied" >Statistique : 16101 21 1998 0 00030 - 
            NIF : 2000024240 - 
            RC : 2012 B 00010 - 
            CIF : 0039668/DGI-F du 01/08/2018<br>
            Coordonnées bancaires :<br>
            Fianarantsoa BNI N° : 00005 00052 473 313 7 010 0 15 - 
            Antananarivo BNI N° : 00005 00001 473 313 7 010 0 04<br>
            <!--Skype : lesscieriesdubetsileo<br>-->
           Site internet :http://scieries-madagascar.com
        </p>
</div> 