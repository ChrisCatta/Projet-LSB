
  	 <div class=" footer well3">
  	 <h4 style="text-align: center">Les scieries du Betsileo</h4>
		<p  class="pied " >tél : +261 20 75 522 44<br>
B.P. 1140 / 301-Fianarantsoa / Madagascar<br>
<a class="pied " href="mailto:lsb@moov.mg">Contacter Les Scieries du Betsileo</a><br>
Skype : lesscieriesdubetsileo<br>
<a class="pied " href="http://scieries-madagascar.com/">Site internet : http://scieries-madagascar.com/</a><br>
<a class="pied " href="https://www.facebook.com/scieries.madagascar/timeline">Facebook : https://www.facebook.com/scieries.madagascar/timeline</a><br>
		</p>
	</div> 	
	</div>	
  </body>
	  <?php
       mysqli_close($link);
       ?>
</html>